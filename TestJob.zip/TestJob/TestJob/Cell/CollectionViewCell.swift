//
//  collectionViewCell.swift
//  TestJob
//
//  Created by Priyanka Sinha on 09/12/23.
//

import Foundation
import UIKit

class  CollectionViewCell: UICollectionViewCell {
   // @IBOutlet weak var imageView: UIImageView!
    
    
    @IBOutlet weak var imageView1: UIImageView!
    
    override func awakeFromNib() {
            super.awakeFromNib()
            
        }
    
}
